# EduControl - Sistema Integral de Gestión Educativa
Listo para desplegar en Vercel.

## Despliegue con Vercel CLI:
```bash
npm install -g vercel
vercel
```

## O mediante GitHub:
1. Sube este contenido a un nuevo repositorio de GitHub.
2. Impórtalo en https://vercel.com/new
3. ¡Listo!